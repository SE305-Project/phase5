import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Doctor2 {
    private String name;
    private Map<String, String> patientProfiles; // Map to store patient profiles with CPR as key

    // Constructor to initialize a Doctor object
    public Doctor2(String name) {
        this.name = name;
        this.patientProfiles = new HashMap<>();
    }

    // Method to view patient profile based on CPR
    public void viewPatientProfile(String patientCPR) {
        String profile = patientProfiles.get(patientCPR);
        if (profile != null) {
            System.out.println("Patient Profile:\n" + profile);
        } else {
            System.out.println("Patient profile not found.");
        }
    }

    // Method to write prescription for a patient based on CPR
    public void writePrescription(String patientCPR, String prescription) {
        patientProfiles.put(patientCPR, prescription);
        System.out.println("Prescription written successfully.\nYou can print it...");
    }
}

public class CreatePrescription {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Doctor2 doctor2 = new Doctor2("Dr. ");

        System.out.println("Hello!");

        System.out.println("Select an action:");
        System.out.println("1. Schedule an appointment");
        System.out.println("2. View patient profile");

        int action = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (action) {
            case 1:
                // Schedule an appointment (USE-CASE1)
                // This case will be handled in the ScheduleAppointments file
                // ...
                break;
            case 2:
                viewPatientProfileAndWritePrescription(scanner, doctor2);
                break;
            default:
                System.out.println("Invalid action.");
                break;
        }

        scanner.close();
    }

    // Method to view patient profile and write prescription
    private static void viewPatientProfileAndWritePrescription(Scanner scanner, Doctor2 doctor2) {
        System.out.print("Enter patient CPR: ");
        String patientCPR = scanner.nextLine();
        doctor2.viewPatientProfile(patientCPR);

        System.out.println("Write prescription (or leave blank to skip): ");
        String prescription = scanner.nextLine();
        if (!prescription.isEmpty()) {
            doctor2.writePrescription(patientCPR, prescription);
        }
    }
}
